package com.myRetail.restapi.repositories;

import org.springframework.data.repository.CrudRepository;

import com.myRetail.restapi.domain.Product;

/**
 *
 * @author Rohit Kanwar
 */
public interface ProductRepository extends CrudRepository<Product, String> {
    @Override
    Product findOne(String id);

}
